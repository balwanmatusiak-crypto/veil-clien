package dev.veil.client;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
public final class VeilScreen extends Screen { public VeilScreen(){super(Text.literal("VEIL Client"));} protected void init(){int x=width/2-110,y=height/2-50;for(Module m:VeilClient.MODULES.all()){Module q=m;addDrawableChild(ButtonWidget.builder(label(q),b->{q.toggle();b.setMessage(label(q));}).dimensions(x,y,220,24).build());y+=32;}addDrawableChild(ButtonWidget.builder(Text.literal("Close"),b->close()).dimensions(x,y,220,24).build());} private Text label(Module m){return Text.literal(m.name()+": "+(m.enabled()?"ON":"OFF"));} public void render(DrawContext c,int mx,int my,float d){renderBackground(c,mx,my,d);c.drawCenteredTextWithShadow(textRenderer,Text.literal("VEIL CLIENT"),width/2,height/2-82,0xFFFFFFFF);super.render(c,mx,my,d);} public boolean shouldPause(){return false;} }
