package dev.veil.client;
import net.minecraft.client.MinecraftClient;
public final class FullbrightModule extends Module { public FullbrightModule(){super("Fullbright");} public void tick(MinecraftClient c){if(c.options.getGamma().getValue()<16)c.options.getGamma().setValue(16.0);}}
