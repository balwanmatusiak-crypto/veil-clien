package dev.veil.client;
import net.minecraft.client.MinecraftClient;
import java.util.*;
public final class ModuleManager { private final List<Module> modules=List.of(new FullbrightModule(),new SprintModule()); public List<Module> all(){return modules;} public void tick(MinecraftClient c){modules.forEach(m->{if(m.enabled())m.tick(c);});} }
