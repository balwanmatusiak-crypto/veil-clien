package dev.veil.client;
import net.minecraft.client.MinecraftClient;
public final class SprintModule extends Module { public SprintModule(){super("Sprint");} public void tick(MinecraftClient c){if(c.player!=null&&c.player.forwardSpeed>0&&!c.player.isSneaking())c.player.setSprinting(true);}}
