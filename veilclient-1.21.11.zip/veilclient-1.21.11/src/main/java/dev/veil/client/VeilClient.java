package dev.veil.client;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
public final class VeilClient implements ClientModInitializer {
 public static final ModuleManager MODULES=new ModuleManager(); private KeyBinding key;
 public void onInitializeClient(){ key=KeyBindingHelper.registerKeyBinding(new KeyBinding("key.veilclient.open_gui",InputUtil.Type.KEYSYM,GLFW.GLFW_KEY_RIGHT_SHIFT,"category.veilclient")); ClientTickEvents.END_CLIENT_TICK.register(c->{while(key.wasPressed()) c.setScreen(c.currentScreen instanceof VeilScreen?null:new VeilScreen()); MODULES.tick(c);}); }
}
