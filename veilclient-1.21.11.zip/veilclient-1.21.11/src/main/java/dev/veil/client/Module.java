package dev.veil.client;
import net.minecraft.client.MinecraftClient;
public abstract class Module { private final String name; private boolean enabled; protected Module(String n){name=n;} public String name(){return name;} public boolean enabled(){return enabled;} public void toggle(){enabled=!enabled;} public void tick(MinecraftClient c){} }
